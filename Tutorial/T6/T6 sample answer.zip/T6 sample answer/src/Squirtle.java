
public interface Squirtle {
	public void shootWater();

}
