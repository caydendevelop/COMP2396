
public interface Pikachu {
	public void shootElectricity();
}
