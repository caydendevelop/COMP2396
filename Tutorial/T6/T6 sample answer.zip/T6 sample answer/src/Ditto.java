
public class Ditto implements Pikachu, Squirtle {
	public void shootElectricity() {}
	public void shootWater() {}
}
