
public class ShinyDitto extends Ditto {
	public void shootElectricity() {
		System.out.println("Shooting electricity!");
	}

	public void shootWater() {
		System.out.println("Shooting water!");
	}
}
